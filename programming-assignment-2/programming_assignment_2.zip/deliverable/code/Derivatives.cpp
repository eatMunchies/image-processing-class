/*
Author: Anthony Silva
Assignment: Programming Assignment 2
Class: Image Processing
Date: 10/20/25
File: Derivates.cpp
Description:
Apply first and second derivative masks to the source images
*/

#include "image.h"
#include "mask.h"
#include "correlationHelper.h"
#include <cstring>
#include <iostream>
#include <cmath>

using namespace std;

int readImageHeader(char[], int&, int&, int&, bool&);
int readImage(char[], ImageType&);
int writeImage(char[], ImageType&);

void magnitude(ImageType& dx, ImageType& dy, ImageType& output) {
    // get the magnitude of the gradient
    int px;
    int py;
    int val;

    // assuming the same dimensions 
    int N, M, Q;
    dx.getImageInfo(N, M, Q);
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j ++) {
            dx.getPixelVal(i, j, px);
            dy.getPixelVal(i, j, py);
            val = sqrt((px * px) + (py * py));
            output.setPixelVal(i, j, val);
        }
    }
}

int main(int argc, char* argv[])
{
    // lenna and sf
    CorrelationHelper correlator;
    char* lennaPath = "./lenna.pgm";
    char* sfPath = "./sf.pgm";

    cout << "init" << endl;

    // lenna
    int N, M, Q;
    bool type;
    readImageHeader(lennaPath, N, M, Q, type);
    ImageType lenna(N, M, Q);
    readImage(lennaPath, lenna);

    cout << "read lenna" << endl;

    // get masks
    Mask prewittx("./prewittX.txt");
    Mask prewitty("./prewittY.txt");
    Mask sobelx("./sobelX.txt");
    Mask sobely("./sobelY.txt");
    Mask laplacian("./laplacian.txt");

    cout << "initialized masks" << endl;

    ImageType lennaPX(N, M, Q);
    ImageType lennaPY(N, M, Q);
    ImageType lennaSX(N, M, Q);
    ImageType lennaSY(N, M, Q);
    ImageType lennaL(N, M, Q);
    ImageType lennaPM(N, M, Q);
    ImageType lennaSM(N, M, Q);
    prewittx.applyMask(lenna, lennaPX, correlator);
    prewitty.applyMask(lenna, lennaPY, correlator);
    sobelx.applyMask(lenna, lennaSX, correlator);
    sobely.applyMask(lenna, lennaSY, correlator);
    laplacian.applyMask(lenna, lennaL, correlator);
    magnitude(lennaPX, lennaPY, lennaPM);
    magnitude(lennaSX, lennaSY, lennaSM);

    cout << "applied masks" << endl;

    char* lennaPXPath = "./lenna_pdy.pgm";
    char* lennaPYPath = "./lenna_pdx.pgm";
    char* lennaSXPath = "./lenna_sdy.pgm";
    char* lennaSYPath = "./lenna_sdx.pgm";
    char* lennaLPath = "./lenna_l.pgm";
    char* lennaPMPath = "./lenna_pm.pgm";
    char* lennaSMPath = "./lenna_sm.pgm";
    writeImage(lennaPXPath, lennaPX);
    writeImage(lennaPYPath, lennaPY);
    writeImage(lennaSXPath, lennaSX);
    writeImage(lennaSYPath, lennaSY);
    writeImage(lennaLPath, lennaL);
    writeImage(lennaPMPath, lennaPM);
    writeImage(lennaSMPath, lennaSM);

    cout << "wrote images" << endl;

    // sf
    readImageHeader(sfPath, N, M, Q, type);
    ImageType sf(N, M, Q);
    readImage(sfPath, sf);

    // get masks
    ImageType sfPX(N, M, Q);
    ImageType sfPY(N, M, Q);
    ImageType sfSX(N, M, Q);
    ImageType sfSY(N, M, Q);
    ImageType sfL(N, M, Q);
    ImageType sfPM(N, M, Q);
    ImageType sfSM(N, M, Q);
    prewittx.applyMask(sf, sfPX, correlator);
    prewitty.applyMask(sf, sfPY, correlator);
    sobelx.applyMask(sf, sfSX, correlator);
    sobely.applyMask(sf, sfSY, correlator);
    laplacian.applyMask(sf, sfL, correlator);
    magnitude(sfPX, sfPY, sfPM);
    magnitude(sfSX, sfSY, sfSM);

    char* sfPXPath = "./sf_pdy.pgm";
    char* sfPYPath = "./sf_pdx.pgm";
    char* sfSXPath = "./sf_sdy.pgm";
    char* sfSYPath = "./sf_sdx.pgm";
    char* sfLPath = "./sf_l.pgm";
    char* sfPMPath = "./sf_pm.pgm";
    char* sfSMPath = "./sf_sm.pgm";
    writeImage(sfPXPath, sfPX);
    writeImage(sfPYPath, sfPY);
    writeImage(sfSXPath, sfSX);
    writeImage(sfSYPath, sfSY);
    writeImage(sfLPath, sfL);
    writeImage(sfPMPath, sfPM);
    writeImage(sfSMPath, sfSM);
}